import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private apiUrl = 'http://localhost:9192/admin';

  constructor(private http: HttpClient) { }

  getCustomerByAccountNo(accNo: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/customer/by-account/${accNo}`);
  }
}