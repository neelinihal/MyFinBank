import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { RegisterService } from '../register.service';
interface Customer {
  customerName: string;
  mobielNo: string;
  email: string;
  password: string;
}
@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {
  customer: Customer = {
    customerName: '',
    mobielNo: '',
    email: '',
    password: '',
  };

  constructor(private registerService: RegisterService, private router: Router) {}

  onSubmit(form: NgForm) {
    if (form.valid) {
         console.log('Registration successful');
         this.router.navigate(['/login']);
    }
  }


}
