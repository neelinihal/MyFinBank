import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AccountApprovalService } from '../account-approval.service';
import { AdminPanelComponent } from '../admin-panel/admin-panel.component';

@Component({
  selector: 'app-account-approval',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,AdminPanelComponent],
  templateUrl: './account-approval.component.html',
  styleUrl: './account-approval.component.css'
})
export class AccountApprovalComponent {
  accNo!: number;
  activate!: boolean;

  constructor(private accountService: AccountApprovalService) { }

  updateAccountStatus(): void {
    if (this.accNo !== undefined && (this.activate === true || this.activate === false)) {
      this.accountService.activateOrDeactivateAccount(this.accNo, this.activate).subscribe(response => {
        alert(response);
        console.log(response);
        this.resetForm();
      }, error => {
        alert('An error occurred while updating the account status.');
        console.log(error);
      });
    } else {
      alert('Please enter a valid Account Number and select an action.');
    }
  }

  private resetForm(): void {
    this.accNo;
    this.activate;
  }
}
