import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,NavbarComponent],
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {
  email: string = '';
  password: string = '';

  constructor(private adminService: AdminServiceService, private router: Router) {}

  onSubmit() {
    this.adminService.login(this.email, this.password).subscribe({
      next: (response) => {
        if (response === 'Success') {
          this.router.navigate(['/all-accounts']);
        } else {
          alert('Login failed');
        }
      },
      error: (error) => {
        alert('Login failed');
      }
    });
  }
}
