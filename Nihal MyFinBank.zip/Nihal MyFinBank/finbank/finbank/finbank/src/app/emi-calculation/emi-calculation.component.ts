import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { EmiCalculationService } from '../emi-calculation.service';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-emi-calculation',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,HeaderComponent],
  templateUrl: './emi-calculation.component.html',
  styleUrl: './emi-calculation.component.css'
})

export class EmiCalculationComponent {
  accNo: number | null = null;
  emiResults: any[] = [];
  errorMessage: string = '';

  constructor(private emiService: EmiCalculationService) { }

  calculateEMI() {
    if (this.accNo !== null) {
      this.emiService.calculateEMI(this.accNo).subscribe(
        data => {
          this.emiResults = data;
          this.errorMessage = '';
        },
        error => {
          this.errorMessage = error;
          this.emiResults = [];
        }
      );
    } else {
      this.errorMessage = 'Account number is required';
    }
  }
}