import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmiCalculationService {
  //private apiUrl = 'http://localhost:9193/api/customers/emi';
  private apiUrl = 'http://localhost:9193/api/loans/emi';
  constructor(private http: HttpClient) { }

  calculateEMI(accNo: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${accNo}`).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      switch (error.status) {
        case 404:
          errorMessage = error.error; 
          break;
        case 400:
          errorMessage = error.error;
          break;
        default:
          errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
    }
    return throwError(errorMessage);
  }
}

  