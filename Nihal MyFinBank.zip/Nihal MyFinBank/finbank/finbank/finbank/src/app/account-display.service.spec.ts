import { TestBed } from '@angular/core/testing';

import { AccountDisplayService } from './account-display.service';

describe('AccountDisplayService', () => {
  let service: AccountDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
