import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanService {


    private apiUrl = 'http://localhost:9192/admin';
  
    constructor(private http: HttpClient) { }
  
    updateLoanStatus(loanId: number, status: string): Observable<any> {
      return this.http.put(`${this.apiUrl}/${loanId}/status?status=${status}`, {});
    }
  }