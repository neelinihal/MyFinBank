import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-deposit-withdraw',
  standalone: true,
  imports: [HeaderComponent, CommonModule, FormsModule,RouterOutlet,RouterLink],
  templateUrl: './deposit-withdraw.component.html',
  styleUrl: './deposit-withdraw.component.css'
})
export class DepositWithdrawComponent {

  depositModel = { AccountNumber: '', amount: 0 };
  withdrawModel = { AccountNumber: '', amount: 0 };

  constructor(private transactionService: TransactionService) {}

  onDepositSubmit() {
    const accNo = +this.depositModel.AccountNumber;
    const amount = this.depositModel.amount;

    if (this.depositModel.amount <= 0) {
      alert('Invalid amount. The deposit amount must be greater than zero.');
      return;
    }
    this.transactionService.deposit(amount, accNo).subscribe(
      response => alert(response),
      error => alert('Deposit Failed: ' + error.error)
    );
  }

  onWithdrawSubmit() {
    const accNo = +this.withdrawModel.AccountNumber;
    const amount = this.withdrawModel.amount;

    if (this.withdrawModel.amount <= 0) {
      alert('Invalid amount. The withdrawal amount must be greater than zero.');
      return;
    }
    this.transactionService.withdraw(amount, accNo).subscribe(
      response => alert(response),
      error => alert('Withdrawal Failed: ' + error.error)
    );
  }
}
