import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
//import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AdminRegisterService } from '../admin-register.service';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-admin-register',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,NavbarComponent],
  templateUrl: './admin-register.component.html',
  styleUrl: './admin-register.component.css'
})
export class AdminRegisterComponent {
  admin = {
    email: '',
    password: ''
  };

  message = '';

  constructor(private adminService: AdminRegisterService, private router: Router) { }

  registerAdmin() {
    if (!this.admin.email || !this.admin.password) {
      this.message = 'All fields must be filled';
      return;
    }

    this.adminService.registerAdmin(this.admin).subscribe(
      response => {
        console.log(response);
        this.message = response;
        if (response === 'Admin registered successfully') {
          console.log(response)
          this.router.navigate(['/admin-login']);
        }
      },
      error => {
        this.message = 'Registration failed.Admin Already Registered';
        console.error('Registration error:', error);
      }
    );
  }
}