import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DemoComponent } from './demo/demo.component';
import { DepositWithdrawComponent } from './deposit-withdraw/deposit-withdraw.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [DepositWithdrawComponent, DemoComponent, RouterOutlet,RegisterComponent,LoginComponent,HeaderComponent,RouterLink,HeaderComponent,DashboardComponent],
 


 
 
 template:`<app-header></app-header>`,
//<app-register></app-register>
templateUrl:'./app.component.html',
//template:'<app-deposit-withdraw></app-deposit-withdraw>',
//`<app-register></app-register>`,
//

//`<app-demo></app-demo>`, 
styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'finbank';
}
