import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
export interface AccountDisplay {
  accNo: number;
  accType: string;
  date: string;
  balance: number;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  private apiUrl = 'http://localhost:9192/admin/allaccounts';

  constructor(private http: HttpClient) { }

  getAllAccounts(): Observable<AccountDisplay[]> {
    return this.http.get<AccountDisplay[]>(this.apiUrl);
  }
}