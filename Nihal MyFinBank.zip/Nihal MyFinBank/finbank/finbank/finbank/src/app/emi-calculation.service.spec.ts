import { TestBed } from '@angular/core/testing';

import { EmiCalculationService } from './emi-calculation.service';

describe('EmiCalculationService', () => {
  let service: EmiCalculationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmiCalculationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
