import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  private baseUrl = 'http://localhost:9193/api/accounts';

  constructor(private http: HttpClient) {}

  deposit(amount: number, accNo: number): Observable<string> {
    const params = new HttpParams().set('deposit', amount.toString());
    return this.http.post(`${this.baseUrl}/deposit/${accNo}`, {}, { params, responseType: 'text' });
  }

  withdraw(amount: number, accNo: number): Observable<string> {
    const params = new HttpParams().set('withdraw', amount.toString());
    return this.http.post(`${this.baseUrl}/withdraw/${accNo}`, {}, { params, responseType: 'text' });
  }
}

