import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AdminPanelComponent } from '../admin-panel/admin-panel.component';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-loan-approval',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,AdminPanelComponent],
  templateUrl: './loan-approval.component.html',
  styleUrl: './loan-approval.component.css'
})
export class LoanApprovalComponent {

    loanId!: number;
    status: string = '';
  
    constructor(private loanService: LoanService) { }
  
    approveLoan(): void {
      this.updateLoanStatus('Approved');
    }
  
    rejectLoan(): void {
      this.updateLoanStatus('Rejected');
    }
  
    private updateLoanStatus(status: string): void {
      if (this.loanId !== null && (status === 'Approved' || status === 'Rejected')) {
        this.loanService.updateLoanStatus(this.loanId, status).subscribe(response => {
          alert('Loan status updated successfully!');
          this.resetForm();
        }, error => {
          alert('An error occurred while updating the loan status.');
        });
      } else {
        alert('Please enter a valid Loan ID and select a status.');
      }
    }
  
    private resetForm(): void {
      this.loanId!;
      this.status = '';
    }
  }