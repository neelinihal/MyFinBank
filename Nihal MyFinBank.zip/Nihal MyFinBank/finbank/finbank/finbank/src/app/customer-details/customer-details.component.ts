import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink, RouterOutlet } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-details',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink],
  templateUrl: './customer-details.component.html',
  styleUrl: './customer-details.component.css'
})
export class CustomerDetailsComponent implements OnInit {
  customer: any;
  loading: boolean = true;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private customerService: CustomerService
  ) { }

  ngOnInit(): void {
    const accNo = +this.route.snapshot.paramMap.get('accNo')!;
    this.customerService.getCustomerByAccountNo(accNo).subscribe({
      next: (data) => {
        this.customer = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'An error occurred while fetching customer details.';
        this.loading = false;
      }
    });
  }

  goToAllAccounts() {
    this.router.navigate(['/all-accounts']);
  }
}