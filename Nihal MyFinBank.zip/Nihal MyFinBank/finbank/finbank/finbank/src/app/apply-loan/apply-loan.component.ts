import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { ApplyLoanService } from '../apply-loan.service';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-apply-loan',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,HeaderComponent],
  templateUrl: './apply-loan.component.html',
  styleUrl: './apply-loan.component.css'
})
export class ApplyLoanComponent {
  loanData = {
    loanType: '',
    amount: null,
    tenure: null,
    accountAccNo: null
  };

  constructor(private loanService: ApplyLoanService) {}

  onSubmit() {
    if (this.loanData.loanType && this.loanData.amount && this.loanData.tenure && this.loanData.accountAccNo) {
      this.loanService.applyLoan(this.loanData).subscribe(
        (response) => {
          alert('Loan application submitted successfully');
        },
        (error) => {
          console.error('Error occurred:', error);
          alert('Error in submitting loan application');
        }
      );
    } else {
      alert('Please fill out all fields.');
    }
  }
}