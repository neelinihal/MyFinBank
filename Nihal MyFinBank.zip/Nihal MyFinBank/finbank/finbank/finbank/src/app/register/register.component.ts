import { CommonModule } from '@angular/common'; // Import CommonModule
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../navbar/navbar.component';
import { RegisterService } from '../register.service';
interface Address {
  houseNo: string;
  streetName: string;
  locality: string;
  city: string;
  country: string;
  pincode: string;
}

interface Account {
  accType: string;
}

interface Customer {
  customerName: string;
  mobielNo: string;
  email: string;
  password: string;
  address: Address[];
  account: Account[];
}

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,NavbarComponent] 
})
export class RegisterComponent {
  accountTypes: string[] = [
    'Savings Account',
    'Current Account',
    'Salary Account',
    'Business Account'
  ];
  customer: Customer = {
    customerName: '',
    mobielNo: '',
    email: '',
    password: '',
    address: [{ houseNo: '', streetName: '', locality: '', city: '', country: '', pincode: '' }],
    account: [{ accType: '' }]
  };

  constructor(private registerService: RegisterService, private router: Router) {}

  onSubmit(form: NgForm) {
    if (form.valid) {
      this.registerService.registerCustomer(this.customer).subscribe(
        response => {
         console.log('Registration successful', response);
         this.router.navigate(['/login']);
        },
        error => {
         
          console.error('Registration failed', error);
        }
      );
    }
  }
}
