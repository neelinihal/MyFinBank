import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransferMoneyService {

  private apiUrl = 'http://localhost:9193/api/accounts/transfer';

  constructor(private http: HttpClient) { }

  transferMoney(fromAccountNumber: string, toAccountNumber: string, amount: number): Observable<string> {
    const params = `?sourceAccNo=${fromAccountNumber}&destAccNo=${toAccountNumber}&amount=${amount}`;
    return this.http.post(`${this.apiUrl}${params}`, {}, {responseType:'text'});
  }
}
