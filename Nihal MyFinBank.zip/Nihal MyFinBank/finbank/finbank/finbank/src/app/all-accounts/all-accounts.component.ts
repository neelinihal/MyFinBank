import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AccountDisplay, AccountService } from '../account-display.service';
import { AdminPanelComponent } from '../admin-panel/admin-panel.component';

@Component({
  selector: 'app-all-accounts',
  standalone: true,
  imports: [CommonModule, FormsModule,RouterOutlet,RouterLink,AdminPanelComponent],
  templateUrl: './all-accounts.component.html',
  styleUrl: './all-accounts.component.css'
})
export class AllAccountsComponent { accounts: AccountDisplay[] = [];

  constructor(private accountService: AccountService, private router: Router) { }

  ngOnInit(): void {
    this.accountService.getAllAccounts().subscribe(data => {
      this.accounts = data;
    });
  }
  viewDetails(accNo: number): void {
    //this.router.navigate(['/customer-details', accNo]);  // Navigate to customer details page
    this.router.navigate(['/customer-details',accNo]);
  }
}