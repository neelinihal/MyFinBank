import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountApprovalService {
  private apiUrl = 'http://localhost:9192/admin';

  constructor(private http: HttpClient) { }

  activateOrDeactivateAccount(accNo: number, activate: boolean): Observable<string> {
    return this.http.put<string>(`${this.apiUrl}/activate-or-deactivate/${accNo}?activate=${activate}`,{}, { responseType: 'text' as 'json' });
  }
}