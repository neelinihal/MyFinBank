export interface Register {
    customerName: string;
    mobielNo: string;
    email: string;
    password: string;
    address: AddressModel[];
    account: AccountModel[];
  }
  
  export interface AddressModel {
    houseNo: string;
    streetName: string;
    locality: string;
    city: string;
    country: string;
    pincode: string;
  }
  
  export interface AccountModel {
    accType: string;
  }
  