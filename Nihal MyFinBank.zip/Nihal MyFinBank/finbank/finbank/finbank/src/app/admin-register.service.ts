import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminRegisterService {
  private baseUrl = 'http://localhost:9192/admin'; // Adjust URL as needed

  constructor(private http: HttpClient) { }

  registerAdmin(admin: any): Observable<string> {
    return this.http.post(`${this.baseUrl}/register`, admin, { responseType: 'text' }).pipe(
      catchError(error => {
        console.error('Registration error:', error);
        return of('Registration failed. Please try again.');
      })
    );
  }
}