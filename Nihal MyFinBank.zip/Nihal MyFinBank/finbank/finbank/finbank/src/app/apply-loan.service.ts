import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplyLoanService {

  private baseUrl = 'http://localhost:9193/api/loans/apply';

  constructor(private http: HttpClient) {}

  applyLoan(loanData: any): Observable<any> {
    return this.http.post(this.baseUrl, loanData, { responseType: 'text' });
  }
}