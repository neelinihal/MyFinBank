import { Routes } from '@angular/router';
import { AccountApprovalComponent } from './account-approval/account-approval.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { AdminRegisterComponent } from './admin-register/admin-register.component';
import { AllAccountsComponent } from './all-accounts/all-accounts.component';
import { ApplyLoanComponent } from './apply-loan/apply-loan.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DepositWithdrawComponent } from './deposit-withdraw/deposit-withdraw.component';
import { EmiCalculationComponent } from './emi-calculation/emi-calculation.component';
import { HeaderComponent } from './header/header.component';
import { LoanApprovalComponent } from './loan-approval/loan-approval.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { TransactionHistoryComponent } from './transaction-history/transaction-history.component';
import { TransferMoneyComponent } from './transfer-money/transfer-money.component';

export const routes: Routes = [
    {component:AdminRegisterComponent,path:'admin-register'},
    {component:AdminLoginComponent,path:'admin-login'},
    {component:AdminDashboardComponent,path:'admin-dashboard'},
    {component:RegisterComponent,path:'register'},
    {component:HeaderComponent,path:'Homepage'},
    {component:DashboardComponent,path:'dashboard'},
    {component:TransactionHistoryComponent,path:'transaction-history'},
    {component:TransferMoneyComponent,path:'transfer-money'},
    {component:DepositWithdrawComponent,path:'deposit-withdraw'},
    {component:ApplyLoanComponent,path:'applyloan'},
    {component:LoginComponent,path:''},
    {component:AdminPanelComponent,path:'admin-panel'},
    {component:AllAccountsComponent,path:'all-accounts'},
    {component:LoanApprovalComponent,path:'loan-approval'},
    {component:AccountApprovalComponent,path:'account-approval'},
    {component:CustomerDetailsComponent,path:'customer-details/:accNo'},
    {component:EmiCalculationComponent,path:'emi'},
  //  {component:LoginComponent,path:'login'},
   // {path: '', redirectTo: 'login', pathMatch: 'full' },
];
