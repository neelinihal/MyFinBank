import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { TransferMoneyService } from '../transfer-money.service';

@Component({
  selector: 'app-transfer-money',
  standalone: true,
  imports: [HeaderComponent,CommonModule, FormsModule,RouterOutlet,RouterLink],
  templateUrl: './transfer-money.component.html',
  styleUrl: './transfer-money.component.css'
})
export class TransferMoneyComponent {
  transferModel = {
    fromAccountNumber: '',
    toAccountNumber: '',
    amount: 0
  };

  constructor(private transferMoneyService: TransferMoneyService) {}

  onSubmit() {
    const { fromAccountNumber, toAccountNumber, amount } = this.transferModel;
    if (!this.isValidAmount(this.transferModel.amount)) {
  alert('Please Enter valid amount.');
  return;
}

    this.transferMoneyService.transferMoney(fromAccountNumber, toAccountNumber, amount)
      .subscribe({
        next: (response:string) => {
          console.log(response);
          this.handleResponse(response);

        },
        error: (error) => {
          console.log('Error',error)
          alert('Transaction failed due to an error');
        }
      });
  }

  private handleResponse(response: string) {
    switch (response) {
      case 'Transfer successful':
        alert('Transaction successful');
        break;
      case 'Transaction failed:Source account not found':
        alert('Transaction failed: Source account not found');
        break;
      case 'Transaction failed:Destination account not found':
        alert('Transaction failed: Destination account not found');
        break;
      case 'Insufficient funds in source account':
        alert('Transaction failed: Insufficient funds in source account');
        break;
      default:
        alert('Transaction failed: ' + response);
        break;
    }
  }

  private isValidAmount(amount: number): boolean {
    return amount > 0;
  }

}
